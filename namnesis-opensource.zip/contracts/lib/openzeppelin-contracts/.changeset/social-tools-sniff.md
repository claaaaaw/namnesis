---
'openzeppelin-solidity': minor
---

`ERC1155`: Introduce the `_checkAuthorized` internal virtual function to encapsulate `isApprovedForAll` and `msg.sender == from` checks.
