---
'openzeppelin-solidity': patch
---

`AccountERC7579`: Do not revert and perform the uninstall if the `onUninstall` hook of a module reverts.
