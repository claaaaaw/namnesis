---
'openzeppelin-solidity': minor
---

`Account`: Update default version of the ERC-4337 entrypoint to v0.9.
