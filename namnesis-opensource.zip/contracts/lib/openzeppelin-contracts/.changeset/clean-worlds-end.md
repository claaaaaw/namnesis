---
'openzeppelin-solidity': minor
---

`ERC20Crosschain`: Added an ERC-20 extension to embed an ERC-7786 based crosschain bridge directly in the token contract.
