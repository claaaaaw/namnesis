---
'openzeppelin-solidity': minor
---

`Arrays`: Add `replace` functions enabling in-place array modification of `address[]`, `bytes32[]` and `uint256[]` arrays, with new content from another array.
