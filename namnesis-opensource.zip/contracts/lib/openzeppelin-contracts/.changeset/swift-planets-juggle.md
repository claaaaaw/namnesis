---
'openzeppelin-solidity': minor
---

`Arrays`: Add `slice` and `splice` functions for value types (`uint256[]`, `bytes32[]`, `address[]`).
