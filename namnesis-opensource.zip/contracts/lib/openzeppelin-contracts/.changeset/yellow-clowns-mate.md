---
'openzeppelin-solidity': patch
---

`RLP`: Fix RLP encoding validity check when decoding long lists or strings
