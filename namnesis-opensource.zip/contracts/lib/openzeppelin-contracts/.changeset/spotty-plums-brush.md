---
'openzeppelin-solidity': minor
---

`ERC4626`: Allow overriding underlying assets transfer mechanisms through new internal virtual functions (`_transferIn` and `_transferOut`).
