---
'openzeppelin-solidity': minor
---

`Bytes`: Add `replace` functions that replaces a portion of a bytes buffer with content from another buffer.
