---
'openzeppelin-solidity': minor
---

`EnumerableSet`: Add support for `Bytes4Set` type.
