---
'openzeppelin-solidity': minor
---

`ERC721URIStorage`: Add `_suffixURI`, an internal getter for retrieving the custom tokenURI without the base prefix.
