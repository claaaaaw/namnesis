---
'openzeppelin-solidity': minor
---

`EnumerableMap`: Add support for `Bytes4ToAddressMap` types.
