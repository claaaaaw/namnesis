---
'openzeppelin-solidity': minor
---

`MessageHashUtils`: Add helper functions to build EIP-712 domain typehash and separator with fields selectively enabled/disabled.
