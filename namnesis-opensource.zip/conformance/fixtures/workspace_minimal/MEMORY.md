# Memory

This is a minimal resurrectum fixture.
