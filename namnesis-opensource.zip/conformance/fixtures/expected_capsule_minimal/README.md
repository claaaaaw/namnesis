Placeholder directory for future golden capsule fixtures.
